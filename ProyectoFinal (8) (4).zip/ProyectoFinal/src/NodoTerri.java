public class NodoTerri {
    private Territorio jugador;
    private NodoTerri anterior;
    private NodoTerri siguiente;

    public NodoTerri(Territorio jugador, NodoTerri anterior, NodoTerri siguiente) {
        this.jugador = jugador;
        this.anterior = anterior;
        this.siguiente = siguiente;
    }

    public Territorio getJugador() {
        return jugador;
    }

    public void setJugador(Territorio jugador) {
        this.jugador = jugador;
    }

    public NodoTerri getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoTerri anterior) {
        this.anterior = anterior;
    }

    public NodoTerri getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoTerri siguiente) {
        this.siguiente = siguiente;
    }
    
}
