import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Lista L = new Lista();
        ListaTerri territorios = new ListaTerri();
        for(int i = 0; i < 4; i++){
            territorios.agregar(new Territorio(7));
        }
        Scanner S = new Scanner(System.in);
        
        int opcion, edad, n = -91;
        String nombre, color;
        
        do{
            System.out.println("\n1. Jugar");
            System.out.println("2. Reglas");
            System.out.println("3. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = S.nextInt();
            if(opcion == 1){
                System.out.println("\n**********Antes de Jugar**********");
                do{
                    if(n != -91)
                        System.out.print("Opción incorrecta. ");
                    System.out.print("Ingresar número de jugadores: ");
                    n = S.nextInt();
                }while(n != 2 && n != 4);
                for(int i = 0; i < n; i++){
                    S.nextLine();
                    System.out.print("Nombre: ");
                    nombre = S.nextLine();
                    System.out.print("Edad: ");
                    edad = S.nextInt();
                    S.nextLine();
                    System.out.print("Color: ");
                    color = S.nextLine();
                    L.agregar(new Jugador(nombre, territorios, edad, 0, color));
                }
                L.jugar(n);
            }else if(opcion == 2){
                System.out.println("\nReglas Básicas"
                        + "\n Unicamente se admitirán 2 o 4 jugadores, los "
                        + "cuales tendrán que elegir colores diferentes para "
                        + "disitinguirse entre bandos. En el juego se tiene dos"
                        + " dados, de ataque y defensa, estos entrarán en juego"
                        + " en cada enfrentamiento, en caso de empate ganará el"
                        + "dado de defensa. Pasado 7 rondas, ganará el bando "
                        + "que posea mas territorios.");
            }else if(opcion != 3){
                System.out.print("\nOpción Incorrecta. Ingresa una opción: ");
                opcion = S.nextInt();
            }
        }while(opcion != 3);
        
        
        
        
        
        /*do{
            
            System.out.println("1. Jugar");
            System.out.println("2. Salir");
            
            System.out.println("\n*****Menú***");
            System.out.println("1. Agregar jugadores");
            System.out.println("2. Cosultar Territorios");
            System.out.println("3. Tabla de Posiciones");
            System.out.println("4. Buscar por Nombre");
            System.out.println("5. Jugar");
            System.out.println("6. Rendirse");
            opcion = S.nextInt();
            
            switch(opcion){
                case 1:
                    System.out.print("Cuántos van a jugar?");
                    int n = S.nextInt();
                    S.nextLine();
                    for(int i = 0; i < n; i++){
                        System.out.println("Nombre: ");
                        nombre = S.nextLine();
                        System.out.println("Edad: ");
                        edad = S.nextInt();
                        S.nextLine();
                        System.out.println("Color: ");
                        color = S.nextLine();
                        L.agregar(new Jugador(nombre, edad, color, territorios));
                    }
                    break;
                    
                case 2:
                    L.cantidad();
                    break;
                    
                case 3:
                    break;
                    
                case 4:
                    break;
                    
                case 5:
                    break;
                    
                default:
                    System.out.println("Opción incorrecta");
            }
        }while(opcion != 5);*/
    }
}