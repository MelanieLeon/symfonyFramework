import java.util.Random;
import java.util.Scanner;

public class Lista {
    private Nodo inicio;
    private Nodo fin;
    
    public Lista(){
        inicio = fin = null;
    }
    public boolean esVacia(){
        return inicio == null && fin == null;
    }
    
    public void agregar(Jugador jugador){
        Nodo N = new Nodo(jugador, fin, null);
        if(esVacia())
            inicio = fin = N;
        else{
            fin.setSiguiente(N);
            fin = N;
            inicio.setAnterior(fin);
            fin.setSiguiente(inicio);
        }
    }
    public void jugar(int n){
        Scanner S = new Scanner(System.in);
        Nodo turno = null;
        while( (turno = empezarTurno()) == null){}
        Nodo aux = turno;
        int opcion, rondas = 0;
        String nombre;
        do{
            System.out.println("\n\t*****Menú de Juego*****");
            System.out.println("Turno: " + aux.getJugador().getNombre());
            System.out.println("\n1. Atacar");
            System.out.println("2. Consultar Territorios");
            System.out.println("3. Tabla de Posiciones");
            System.out.println("4. Buscar por nombre");
            System.out.println("5. Rendirse");
            System.out.println("6. Terminar Turno");
            System.out.print("Ingresar una opción: ");
            opcion = S.nextInt();
            
            switch(opcion){
                case 1:
                    atacar(aux);
                    break;
                case 2:
                    cantidad();
                    break;
                case 3:
                    posiciones();
                    break;
                case 4:
                    System.out.print("Ingresar nombre a buscar: ");
                    S.nextLine();
                    nombre = S.nextLine();
                    buscar(nombre);
                    break;
                case 5:
                    aux = rendirse(aux.getJugador());
                    if(esVacia())
                        rondas = n * 7;
                    rondas++;
                    break;
                case 6:
                    aux = aux.getSiguiente();
                    rondas++;
                    break;
                default:
                    System.out.println("Opción incorrecta bro, inténtalo de nuevo.");
                    break;
            }
        }while(rondas/n < 7);
        System.out.println("\tJuego Finalizado");
        posiciones();
    }
    public Nodo empezarTurno(){
        Nodo aux = inicio;
        int cont = 0;
        do{
            System.out.println("Dados de " + aux.getJugador().getNombre() + ": " 
                    + aux.getJugador().setDado(generarDado()));
            aux = aux.getSiguiente();
        }while(aux != inicio);
        Nodo max = aux;
        aux = aux.getSiguiente();
        do{
            if(aux.getJugador().getDado() > max.getJugador().getDado())
                max = aux;
            aux = aux.getSiguiente();
        }while(aux != inicio);
        do{
            if(aux.getJugador().getDado() == max.getJugador().getDado())
                cont++;
            aux = aux.getSiguiente();
        }while(aux != inicio);
        if(cont > 1){
            System.out.println("\tEl número mas alto se repite, se volverán a botar los dados\n");
            return null;
        }
        return max;
    }
    
    
    
    public void atacar(Nodo jugador){
        if(jugador.getJugador().getTerritorio().verificarTerritorios() == 0){
            System.out.println("No tienes tropas suficientes para atacar.");
            return;
        }
        Scanner S = new Scanner(System.in);
        Nodo aux = inicio;
        int cont = 1;
        boolean Flag = false;
        do{
            if(aux != jugador){
                System.out.println(cont + ". " + aux.getJugador().getNombre());
                cont++;
            }
            aux = aux.getSiguiente();
        }while(aux != inicio);
        while(Flag == false){
            System.out.print("\nIngresa el nombre del jugador a atacar: ");
            String nom = S.nextLine();
            do{
                if(aux != jugador){
                    if(nom.compareToIgnoreCase(aux.getJugador().getNombre()) == 0){
                        Flag = true;
                        break;
                    }
                }
                aux = aux.getSiguiente();
            }while(aux != inicio);
            if(Flag == false){
                System.out.println("\nNo se encontraron coincidencias.");
            }
        }
        //Selección de Territorios
        int numTerri = aux.getJugador().getTerritorio().territorios();//Número de territorios del defensor
        System.out.print("\nSelecciona el territorio a atacar: ");
        int terr = S.nextInt();
        while(terr > numTerri || terr < 1){
            System.out.print("Opción incorrecta. ");
            System.out.print("Selecciona el territorio a atacar: ");
            terr = S.nextInt();
        }
        System.out.println("Dados de " + jugador.getJugador().getNombre() + ": " + jugador.getJugador().setDado(generarDado()));
        System.out.println("Dados de " + aux.getJugador().getNombre() + ": " + aux.getJugador().setDado(generarDado()));
        
        if(aux.getJugador().getDado() >= jugador.getJugador().getDado()){
            aux.getJugador().getTerritorio().agregar(
                    new Territorio(jugador.getJugador().getTerritorio().getInicio().getJugador().getTropas()));
            jugador.getJugador().getTerritorio().eliminarTerri();
        }else{
            jugador.getJugador().getTerritorio().agregar(
                    new Territorio(aux.getJugador().getTerritorio().getInicio().getJugador().getTropas()));
            aux.getJugador().getTerritorio().eliminarTerri();
        }
    }
    public Nodo rendirse(Jugador buscar){
        Nodo aux = inicio;
        do{
            if(aux.getJugador().getNombre().compareToIgnoreCase(buscar.getNombre()) == 0){
                break;
            }
            aux = aux.getSiguiente();
        }while(aux != inicio);
        if(inicio == fin){
            inicio = fin = null;
        }else if(aux == inicio){
            fin.setSiguiente(aux.getSiguiente());
            aux.getSiguiente().setAnterior(fin);
            inicio = inicio.getSiguiente();
        }else if(aux == fin){
            inicio.setAnterior(fin.getAnterior());
            fin.getAnterior().setSiguiente(inicio);
            fin = fin.getAnterior();
        }else{
            aux.getAnterior().setSiguiente(aux.getSiguiente());
            aux.getSiguiente().setAnterior(aux.getAnterior());
        }
        aux.setAnterior(null);
        aux.setSiguiente(null);
        return inicio;
    }
    public void buscar(String nombre){
        System.out.println(nombre);
        Nodo aux = inicio;
        boolean Flag = false;
        do{
            if(nombre.compareToIgnoreCase(aux.getJugador().getNombre()) == 0){
                System.out.println(aux.getJugador());
                Flag = true;
                break;
            }
            aux = aux.getSiguiente();
        }while(aux != inicio);
        if(Flag == false)
            System.out.println("No se encontraron coincidencias con " + nombre);
    }
    public void cantidad(){
        Nodo aux = inicio;
        int acum;
        int cont = 0;
        do{
            cont++;
            acum = aux.getJugador().getTerritorio().cantidad();
            System.out.println("Cantidad de territorios del jugador " + cont + ": " + acum);
            aux = aux.getSiguiente();
        }while(aux != inicio);
    }
    public void posiciones(){
        if(esVacia())
            return;
        System.out.println("\n*******Tabla de Posiciones*******");
        Nodo aux = inicio;
        int cont = 1;
        for(int i=6; i>0; i--){
            do{
                if(aux.getJugador().getTerritorio().numTerritorios() == i){
                    System.out.println(cont + ". " + aux.getJugador().getNombre());
                    cont++;
                }
                aux = aux.getSiguiente();
            }while(aux != inicio); 
        }
    }
    public int generarDado(){
        Random rand = new Random();
        return rand.nextInt(5) + 1;
    }
}
