public class ListaTerri {
    private NodoTerri inicio;
    private NodoTerri fin;
    
    public ListaTerri(){
        inicio = fin = null;
    }
    public boolean esVacia(){
        return inicio == null && fin == null;
    }
    
    public void agregar(Territorio territorio){
        NodoTerri N = new NodoTerri(territorio, fin, null);
        if(esVacia())
            inicio = fin = N;
        else{
            fin.setSiguiente(N);
            fin = N;
            inicio.setAnterior(fin);
            fin.setSiguiente(inicio);
        }
    }

    public NodoTerri getInicio() {
        return inicio;
    }
    
    public int cantidad(){
        if(esVacia()){
            return 0;
        }
        else{
            NodoTerri aux = inicio;
            int cont = 0;
            do{
                cont++;
                aux = aux.getSiguiente();
            }while(aux != inicio);
            return cont;
        }
    }
    
    public int territorios(){
        NodoTerri aux = inicio;
        int cont = 0;
        do{
            cont++;
            System.out.println("Territorio " + cont + ": " + aux.getJugador().getTropas() + "tropas.");
            aux = aux.getSiguiente();
        }while(aux != inicio);
        return cont;
    }
    public int numTerritorios(){
        NodoTerri aux = inicio;
        int cont = 0;
        do{
            cont++;
            aux = aux.getSiguiente();
        }while(aux != inicio);
        return cont;
    }
    public int tropas(int cont){
        NodoTerri aux = inicio;
        for(int i=0; i<cont; i++)
            aux = aux.getSiguiente();
        return aux.getJugador().getTropas();
    } 
    public int verificarTerritorios(){
        NodoTerri aux = inicio;
        boolean Flag = false;
        do{
            if(aux.getJugador().getTropas() > 1)
                Flag = true;
            aux = aux.getSiguiente();
        }while(aux != inicio);
        if(Flag == true)
            return 1;
        else
            return 0;
    }
    public void eliminarTerri(){
        if(inicio == fin){
            inicio = fin = null;
        }
        fin.setSiguiente(inicio.getSiguiente());
        inicio.getSiguiente().setAnterior(fin);
        inicio.setSiguiente(null);
        inicio.setAnterior(null);
        inicio = fin.getSiguiente();
    }
}
