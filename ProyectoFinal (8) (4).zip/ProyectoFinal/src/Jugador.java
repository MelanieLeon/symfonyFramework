public class Jugador {
    private String nombre;
    private ListaTerri territorio;
    private int edad;
    private int dado;
    private String color;

    public Jugador(String nombre, ListaTerri territorio, int edad, int dado, String color) {
        this.nombre = nombre;
        this.territorio = territorio;
        this.edad = edad;
        this.dado = dado;
        this.color = color;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTerritorio(ListaTerri territorio) {
        this.territorio = territorio;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int setDado(int dado) {
        return this.dado = dado;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public ListaTerri getTerritorio() {
        return territorio;
    }

    public int getEdad() {
        return edad;
    }

    public int getDado() {
        return dado;
    }

    public String getColor() {
        return color;
    }

    @Override
    public String toString() {
        return "Jugador{" + "nombre=" + nombre + ", territorio=" + territorio.territorios() + ", edad=" + edad + ", color=" + color + '}';
    }
    
    
}
