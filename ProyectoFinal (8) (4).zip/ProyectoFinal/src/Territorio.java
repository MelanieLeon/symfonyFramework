public class Territorio {
    private int tropas;

    public Territorio(int tropas) {
        this.tropas = tropas;
    }

    public int getTropas() {
        return tropas;
    }

    public void setTropas(int tropas) {
        this.tropas = tropas;
    }

    @Override
    public String toString() {
        return "Territorio{" + "tropas=" + tropas + '}';
    }
}
