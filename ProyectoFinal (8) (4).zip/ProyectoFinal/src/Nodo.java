public class Nodo {
    private Jugador jugador;
    private Nodo anterior;
    private Nodo siguiente;

    public Nodo(Jugador jugador, Nodo anterior, Nodo siguiente) {
        this.jugador = jugador;
        this.anterior = anterior;
        this.siguiente = siguiente;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public Nodo getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo anterior) {
        this.anterior = anterior;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
    
    
}
